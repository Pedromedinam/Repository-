
package ConexionBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {

    static String url = "jdbc:postgresql://localhost:5432/postgree";
    static String user = "postgres";
    static String pass = "estudiante";
    static Connection conexion = null;
    String driverDb = "org.postgresql.Driver";
    
    public Connection conectar(){
        try{
            Class.forName(driverDb);
            conexion  = DriverManager.getConnection(url, user, pass);
            if(!conexion.isClosed()){
                System.out.println("Conectado");
            }return conexion;
        } catch(ClassNotFoundException | SQLException ex){
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public Connection getConexion(){
        return conexion;
    }
}
