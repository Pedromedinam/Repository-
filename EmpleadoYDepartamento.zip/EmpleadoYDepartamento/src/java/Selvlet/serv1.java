package Selvlet;

import ConexionBD.Conexion;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "serv1", urlPatterns = {"/serv1"})
public class serv1 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {

        Conexion con = new Conexion();
        con.conectar();
        String sql = "INSERT INTO empleados (Id, Nombres, Apellidos, Fecha)"
                + "VALUES (?, ?, ?, ?)";
        String sql2 = "INSERT INTO departamento (Idd, Nombre, Direccion)"
                + "VALUES (?, ?, ?)";
        try (PreparedStatement pst = con.getConexion().prepareStatement(sql)) {
            pst.setString(1, request.getParameter("id"));
            out.println(request.getParameter("id"));
            pst.setString(2, request.getParameter("nombre"));
            out.println(request.getParameter("nombre"));
            pst.setString(3, request.getParameter("apellidos"));
            out.println(request.getParameter("apellidos"));
            pst.setString(4, request.getParameter("fecha"));
            out.println(request.getParameter("fecha"));
            pst.execute();
            request.getRequestDispatcher("salida.jsp").forward(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(serv1.class.getName()).log(Level.SEVERE, null, ex);
        }
        try (PreparedStatement pst = con.getConexion().prepareStatement(sql2)) {
            pst.setString(1, request.getParameter("idd"));
            pst.setString(2, request.getParameter("nombred"));
            pst.setString(3, request.getParameter("direccion"));
            pst.execute();
            request.getRequestDispatcher("salida.jsp").forward(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(serv1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(serv1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(serv1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(serv1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(serv1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
